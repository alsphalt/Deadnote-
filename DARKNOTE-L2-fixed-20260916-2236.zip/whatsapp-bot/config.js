'use strict'

// DARKNOTE Telegram configuration
// Keep this file private. Do not commit it to a public repository.
module.exports = {
    TELEGRAM_BOT_TOKEN: '8615317958:AAG4YbOHlqinV48oNKXNlPOtSEAV81M2tO8 '
}
