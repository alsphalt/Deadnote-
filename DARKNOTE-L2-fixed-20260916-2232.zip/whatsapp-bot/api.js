'use strict'

// DARKNOTE API configuration. Keep this file private.
// API credentials are intentionally separate from the Telegram bot token.
module.exports = {
    MZAZI_API_KEY: 'mzazi_c_zHM8uR_PLAXWmFRPd9SLhbLATKWD0H',
    MZAZI_API_KEY_IMAGE: '',
    GENIUS_LYRICS_API_KEY: 'mzazi_c_zHM8uR_PLAXWmFRPd9SLhbLATKWD0H',
    BASE_URL: 'https://www.mzazi.shop'
}
